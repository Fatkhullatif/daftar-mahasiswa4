package data

class BookDao {
}