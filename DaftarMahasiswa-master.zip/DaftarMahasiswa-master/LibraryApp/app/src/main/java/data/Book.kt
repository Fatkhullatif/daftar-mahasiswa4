package data

class Book {
}