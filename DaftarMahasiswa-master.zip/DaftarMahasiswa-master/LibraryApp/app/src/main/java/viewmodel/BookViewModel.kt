package viewmodel

class BookViewModel {
}