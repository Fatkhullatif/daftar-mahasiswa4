package repository

class BookRepository {
}