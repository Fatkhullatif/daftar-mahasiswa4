package adapter

class BookAdapter {
}